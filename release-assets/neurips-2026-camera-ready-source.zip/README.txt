Generated from the shared camera-ready source. Compile main.tex with XeLaTeX, BibTeX, XeLaTeX, XeLaTeX. The included main.bbl also supports direct compilation. This export selects final style.
